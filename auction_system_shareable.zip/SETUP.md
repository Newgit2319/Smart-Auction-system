# Auction System - Setup & Running Instructions

This project is a real-time auction platform with a **Spring Boot (Java)** backend and a **Vanilla JS/HTML** frontend.

---

## 📋 Prerequisites
Ensure you have the following installed:
- **Java 17** (OpenJDK)
- **MySQL Server**
- **Maven** (optional, the project includes `./mvnw` wrapper)
- **A modern web browser**

---

## 🛠️ Step 1: Database Configuration
The application expects a MySQL database named `auction_db` with specific credentials.

1.  **Open MySQL terminal:**
    ```bash
    sudo mysql -u root
    ```

2.  **Run these commands to set up the database and user:**
    ```sql
    CREATE DATABASE IF NOT EXISTS auction_db;
    -- Set the password to 'Mighty12' (as configured in application.properties)
    ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'Mighty12';
    FLUSH PRIVILEGES;
    EXIT;
    ```

---

## ⚙️ Step 2: Build the Backend
Navigate to the backend directory and build the project using the Maven wrapper.

1.  **Navigate to backend:**
    ```bash
    cd auction-system--/backend
    ```

2.  **Make Maven wrapper executable and build:**
    ```bash
    chmod +x mvnw
    ./mvnw clean install -DskipTests
    ```

---

## 🚀 Step 3: Run the Application

### Option A: Automatic (Recommended)
Use the provided script in the root directory to start the backend.
```bash
./run.sh
```

### Option B: Manual Backend Start
```bash
cd auction-system--/backend
./mvnw spring-boot:run
```
The backend will start on **http://localhost:8083**.

---

## 🌐 Step 4: Access the Frontend
The frontend does not require a separate server. You can open the HTML files directly in your browser.

1.  Navigate to the `frontend/` directory.
2.  Open `login.html` in your browser (Double-click the file or right-click -> Open with Browser).
3.  **Registration:** If you don't have an account, go to `register.html` first.
4.  **Flow:** Register -> Login -> Dashboard (home.html) -> Product Details (product.html).

---

## 🧪 Testing the Real-time Features
To test the real-time bid updates:
1.  Open two different browser windows or use Incognito mode for the second one.
2.  Log in as a **Seller** in Window 1 and list a product.
3.  Log in as a **Buyer** in Window 2 and go to that product's page.
4.  Place a bid in Window 2; you will see the price update instantly in Window 1 if you are on the same product page.

---

## 📂 Project Structure
- `/backend`: Spring Boot source code, controllers, models, and repositories.
- `/frontend`: HTML, CSS, and `app.js` for the client-side logic.
- `run.sh`: Script to start the backend.
- `setup_and_run.sh`: One-click installation script (Linux only).
