# 🔨 How to Run the Auction System

Follow these steps to get the system up and running on your local machine.

## 1. Prerequisites
- **Java 17** installed.
- **MySQL** installed and running.

## 2. Database Setup
1. Open your MySQL terminal.
2. Create the database:
   ```sql
   CREATE DATABASE auction_db;
   ```
3. (Optional) If you need to match the project's default credentials:
   ```sql
   ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'Mighty12';
   FLUSH PRIVILEGES;
   ```

## 3. Start the Backend
Navigate to the `backend` folder and run the Maven wrapper:
```bash
cd backend
./mvnw spring-boot:run
```
*The server will start on http://localhost:8083.*

## 4. Open the Frontend
You don't need a server for the frontend. Simply go to the `frontend` folder and open **`login.html`** in any modern web browser (Chrome, Firefox, Edge).

## 5. Testing Real-Time Bidding
1. Open **two different browser windows**.
2. Log in as a **Seller** in Window 1 and list a product.
3. Log in as a **Buyer** in Window 2 and go to that product.
4. Place a bid in Window 2; you will see the price update instantly in Window 1!

---
*Note: If you are on Linux, you can also use the `run.sh` script in the root to start the backend quickly.*
